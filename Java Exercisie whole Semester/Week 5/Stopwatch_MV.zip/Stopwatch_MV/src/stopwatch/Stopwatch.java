//Stopwatch.java
package stopwatch;

/**
 * @author Peter Rosner
 * @version 3.0 February 2015
 * Contains main() method for artefact
 * Kicks off the View (instead of the controller)
 */
public class Stopwatch {
    
    /**
     * creates a StopwatchController and starts it up
     */
    public static void main(String[] args) {
        //StopwatchController sc = new StopwatchController();
        //StopwatchController sc = new StopwatchController();
        //sc.start();
        StopwatchView view = new StopwatchView();
        view.show();
    }
}
