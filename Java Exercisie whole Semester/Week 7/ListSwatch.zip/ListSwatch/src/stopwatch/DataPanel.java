package stopwatch;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

/**
 *
 * @author Peter Rosner
 * Subclass of JPanel for displaying  the data corresponding to a stopwatch run:
 * Name, club, speed quality, and whether accepted for the team
 */
public class DataPanel extends JPanel {

    //fields
    private JPanel namePanel;
    private JPanel clubPanel;
    private JPanel speedPanel;
    private JPanel acceptPanel;
    private JPanel savePanel;
    private JLabel nameLabel;
    private JLabel clubLabel;
    private JTextField name;
    private JComboBox club;
    private JRadioButton speedGood;
    private JRadioButton speedModerate;
    private JRadioButton speedPoor;
    private JCheckBox accept;
    private JButton saveButton;
    private ButtonGroup speedGroup;
    private static final Object[] clubList = {"Belgrave Harriers", "Loughborough", "Newcastle Road Stars", "Hounslow and Feltham"};

    /**
     * Constructor creates new DataPanel
     * and registers inner class SaveActionListener
     * the ListSwatchController as listener for the the Save button.
     * @param controller the ListSwatchController instance containing this inner classes 
     */
    public DataPanel(ListSwatchController controller) {

        this.setLayout(new GridLayout(5, 1, 1, 1));
        this.setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.black),
                "Details and Assessment"));

        namePanel = new JPanel();
        clubPanel = new JPanel();
        speedPanel = new JPanel();
        acceptPanel = new JPanel();
        savePanel = new JPanel();

        nameLabel = new JLabel("Name: ");
        nameLabel.setFont(new Font("Dialog", Font.BOLD, 12));
        clubLabel = new JLabel("Club: ");
        clubLabel.setFont(new Font("Dialog", Font.BOLD, 12));

        name = new JTextField(15);
        club = new JComboBox(clubList);
        speedGood = new JRadioButton("Good");
        speedModerate = new JRadioButton("Moderate");
        speedPoor = new JRadioButton("Poor");
        accept = new JCheckBox("Accept");
        saveButton = new JButton("Save and Reset");
        saveButton.addActionListener(controller.new SaveActionListener());

        speedGroup = new ButtonGroup();
        speedGroup.add(speedGood);
        speedGroup.add(speedModerate);
        speedGroup.add(speedPoor);
        speedGroup.setSelected(speedModerate.getModel(), true);
        
        namePanel.add(nameLabel);
        namePanel.add(name);

        clubPanel.add(clubLabel);
        clubPanel.add(club);

        speedPanel.add(speedPoor);
        speedPanel.add(speedModerate);
        speedPanel.add(speedGood);

        acceptPanel.add(accept);

        savePanel.add(saveButton);

        this.add(namePanel);
        this.add(clubPanel);
        this.add(speedPanel);
        this.add(acceptPanel);
        this.add(savePanel);

    }
    
    /**
     * Get whether Accept check box has been ticked by the user
     * @return boolean true or false
     */
    public boolean getAccepted() {
        return accept.isSelected();
    }

    /*
     * Get the speed quality from the radio button selected 
     * @return the string "Poor", "Moderate" or "Good"
     */
    public String getSpeedQuality() {
        if (speedPoor.isSelected()) {
            return "Poor";
        } else if (speedModerate.isSelected()) {
            return "Moderate";
        } else {
            return "Good";
        }
    }

    /**
     * get the name of the runner
     * @return the runner's name as a String
     */
    public String getName() {
        return name.getText();
    }

    /**
     * Get the club of the runner
     * @return the club name as a String
     */
    public String getClub() {
        return (String) (club.getSelectedItem());
    }

    /**
     * enable or disable the user-modifiable data associated with the runner
     * @param b boolean true (enable), or false (disable)
     */
    public void enableDataControls(boolean b) {
        club.setEnabled(b);
        speedPoor.setEnabled(b);
        speedModerate.setEnabled(b);
        speedGood.setEnabled(b);
        name.setEnabled(b);
        accept.setEnabled(b);
        saveButton.setEnabled(b);
    }
}
