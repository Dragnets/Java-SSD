
//ListPanel
package stopwatch;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

/**
 *
 * @author Peter Rosner, Version 2.0 modified March 2014
 * Subclass of JPanel for displaying  the data corresponding to a stopwatch run:
 * Name, club, speed quality, and whether accepted for the team
 */
public class ListPanel extends JPanel {

    //fields
    private JPanel backPanel;
    private JScrollPane listHolder;
    private DefaultListModel listModel;
    private JList list;
    private JButton backButton;

    /**
     * Constructor creates new DataPanel
     * and registers inner class SaveActionListener
     * the ListSwatchController as listener for the the Save button.
     * @param controller the ListSwatchController instance containing this inner classes 
     */
    public ListPanel(ListSwatchController controller) {

        this.setLayout(new BorderLayout());
        list = new JList();
        listHolder = new JScrollPane(list,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        
        listModel = new DefaultListModel();
        list.setModel(listModel);
       
        
        backButton = new JButton("Back");
        backPanel = new JPanel();
        backPanel.add(backButton);
        this.add(listHolder,BorderLayout.CENTER);
        this.add(backPanel,BorderLayout.SOUTH);
        
        backButton.addActionListener(controller.new BackActionListener());
        list.addListSelectionListener(controller.new ListListener());
    }
    
    /**
     * display the records in the JList from the list obtained from the model, 
     * extracting the name, club, quality and accepted/not data from each record
     * @param records the list of records obtained from the model
     */
    /**
    public void setRecords(Entry[] records){
        this.listModel.clear();
        for (Entry element:records){
            listModel.addElement(element.getTime() + "  " 
                    + element.getName() + "  "
                    + element.getClub() + "  "
                    + element.getQuality() + "  "
                    + element.getAccepted());
        }
    }
    */
    
    /** add an Entry to the JList by appending its String representation
     * to the end of the model for the JList
     * @param the Entry (from the Model for the application)
     */
    
    public void addEntry (Entry entry){
        listModel.addElement(entry);
    }
}
