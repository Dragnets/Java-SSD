//Stopwatch.java
package stopwatch;

/**
 * @author Peter Rosner
 * @version 2.0 January 2013
 * Contains main() method for artefact
 * Kicks off the Controller
 */
public class ListSwatch {
    
    /**
     * creates a ListSwatchController and starts it up
     */
    public static void main(String[] args) {
        //StopwatchController sc = new ListSwatchController();
        ListSwatchController sc = new ListSwatchController();
        sc.start();
    }
}
