// ListSwatchView.java
package stopwatch;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

/**
 * Presentation class for a system simulating a stopwatch with Start, Stop and
 * Reset buttons. This it the View part of the MVC architecture
 *
 * @author Pete Rosner
 * @version 2.2 February 2015
 */
public class ListSwatchView implements Observer {

    private StopwatchPanel stopwatchPanel;
    private DataPanel dataPanel;
    private ListPanel listPanel;
    private JPanel listSwatchPanel;
    private JPanel loggingStopwatchPanel;
    private CardLayout cards;
    //private StopwatchPanel2 stopwatchPanel;
    private JFrame frame;

    /**
     * The constructor creates the frame and places a panel containing all of
     * the stopwatch components inside it
     */
    public ListSwatchView(ListSwatchController controller) {

        super();
        this.setResources();

        frame = new JFrame("Stopwatch");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        stopwatchPanel = new StopwatchPanel(controller);
        //stopwatchPanel = new StopwatchPanel2(controller);
        dataPanel = new DataPanel(controller);
        loggingStopwatchPanel = new JPanel();
        loggingStopwatchPanel.setLayout(new BorderLayout());
        loggingStopwatchPanel.add(stopwatchPanel, BorderLayout.NORTH);
        loggingStopwatchPanel.add(dataPanel, BorderLayout.SOUTH);

        listPanel = new ListPanel(controller);

        cards = new CardLayout();
        listSwatchPanel = new JPanel();
        listSwatchPanel.setLayout(cards);

        listSwatchPanel.add(loggingStopwatchPanel, "stopwatch");
        listSwatchPanel.add(listPanel, "history");


        frame.add(listSwatchPanel);
        frame.pack();
    }

    /**
     * Displays the frame and its contents
     */
    public void show() {
        frame.setVisible(true);
    }

    public boolean getAccepted() {
        return dataPanel.getAccepted();
    }

    public String getSpeedQuality() {
        return dataPanel.getSpeedQuality();
    }

    public String getName() {
        return dataPanel.getName();
    }

    public String getClub() {
        return dataPanel.getClub();
    }

    /**
     * if the arg is the string corresponding to time get the time from the
     * Observable object and get the stopwatch panel to display it. If the arg
     * is the string corresponding to record added get the stopwatch panel to
     * add it to its list of records.
     *
     * @param observable - the Model from which the formatted time or records
     * are obtained
     * @param arg - the string representing the time property, or the records
     * property
     */
    @Override
    public void update(Observable observable, Object arg) {
        if (arg.equals(Properties.TIME)) {
            stopwatchPanel.setTime(((ElapsedTimer) observable).getTime());
        } else if (arg.equals(Properties.RECORDS)) {
            listPanel.addEntry(((Logger) observable).getLastEntry());
        }
    }

    /**
     * Sets the appropriate sensitivities for the reset state for the stopwatch
     */
    public void setResetState() {
        cards.show(listSwatchPanel, "stopwatch");
        stopwatchPanel.setButtons(true, false, false);
        dataPanel.enableDataControls(false);
    }

    /**
     * Sets the appropriate sensitivities for the running state for the
     * stopwatch
     */
    public void setRunningState() {
        stopwatchPanel.setButtons(false, true, false);
        dataPanel.enableDataControls(false);
    }

    /**
     * Sets the appropriate sensitivities for the stopped state for the
     * stopwatch
     */
    public void setStoppedState() {
        stopwatchPanel.setButtons(false, false, true);
        dataPanel.enableDataControls(true);
    }

    /**
     * Sets the appropriate sensitivities for the ListDisplay state for the
     * stopwatch
     */
    public void setListDisplayState() {
        cards.show(listSwatchPanel, "history");
    }

    /**
     * set up the default display properties for fonts and Swing components
     */
    private void setResources() {

        ColorUIResource defaultBackground = new ColorUIResource(Color.white);
        ColorUIResource defaultForeground = new ColorUIResource(Color.black);
        ColorUIResource disabledColor = new ColorUIResource(Color.lightGray);

        FontUIResource smallFont = new FontUIResource(
                new Font("Dialog", Font.BOLD, 12));
        FontUIResource bigFont = new FontUIResource(
                new Font("Dialog", Font.BOLD, 16));

        UIManager.put("Button.background",
                defaultBackground);
        UIManager.put("Button.foreground",
                defaultForeground);
        UIManager.put("Button.disabledText",
                disabledColor);
        UIManager.put("Button.font", smallFont);


        UIManager.put("Label.background",
                defaultBackground);
        UIManager.put("Label.foreground",
                defaultForeground);
        UIManager.put("Label.font", bigFont);

        UIManager.put("Panel.background",
                defaultBackground);
        UIManager.put("Panel.foreground",
                defaultForeground);
    }
}
