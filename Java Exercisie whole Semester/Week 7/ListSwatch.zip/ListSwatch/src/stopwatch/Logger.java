//Logger
package stopwatch;

import java.util.ArrayList;
import java.util.Observable;

/**
 * This class is for logging a data from the logging stopwatch to the console
 * @author Peter Rosner
 * @version 2.0 March 2013 - made Logger extend Observable
 */
public class Logger extends Observable {
    
  //
  private ArrayList<Entry> records = null;
  private Entry lastEntry = null;
  //
  public Logger() {
    super();
    records = new ArrayList <Entry> (); 
  }
  
  /**
   *Carry out the logging with the supplied parameters
   *@param time the time recorded
   *@param name the name of the runner
   *@param club his or her club
   *@param quality speed quality which may be String "poor", "moderate" or "good"
   *@param accepted indicating acceptance - may be string "accepted" or "not accepted"
   */
  public void log(String time,String name, String club, String quality, boolean accepted){
    
    System.out.println();
    System.out.println(time);
    System.out.println(name);
    System.out.println(club);
    System.out.println(quality);
    if (accepted){
        System.out.println("accepted");
    } else {
        System.out.println("not accepted");
    }
    lastEntry = new Entry(time, name, club, quality,accepted);
    records.add(lastEntry);
    this.setChanged();
    this.notifyObservers(Properties.RECORDS);
  }
  
  public Entry getLastEntry () {
      return lastEntry;
  }
  
  /**
   * get all the records 
   * @return an array of the records
   * 
   */
  
  public Entry[] getRecords(){
      return records.toArray(new Entry[records.size()]);
  }
}