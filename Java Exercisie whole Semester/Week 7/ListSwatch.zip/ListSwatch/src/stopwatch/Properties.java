//Properties.java
package stopwatch;

/*
 * Contains global properties to be used by both the View and the Model
 */

/**
 *
 * @author peterrosner
 * @version 1.1 March 2013
 */
public class Properties {
    public static String TIME = "time";
    public static String RECORDS = "records";
}
