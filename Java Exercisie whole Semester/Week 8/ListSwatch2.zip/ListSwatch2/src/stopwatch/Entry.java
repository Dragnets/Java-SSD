/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package stopwatch;

/**
 *
 * @author peterrosner
 */
public class Entry {
    private String time = null;
    private String name = null;
    private String club = null;
    private String quality = null;
    private boolean accepted = false;

    public Entry(String time, String name, String club, String quality, boolean accepted) {
        this.time = time;
        this.name = name;
        this.club = club;
        this.quality = quality;
        this.accepted = accepted;
    }
    public String getTime() {
        return this.time;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getClub() {
        return this.club;
    }
    
    public String getQuality() {
        return this.quality;
    }
    
    public String getAccepted() {
        if (accepted){
            return "accepted";
        } else {
            return "not accepted";
        }
    }
    
    public String toString() {
        return time + " " + name + " " + club + " " + " " + quality + " " + accepted;
    }

    
}
