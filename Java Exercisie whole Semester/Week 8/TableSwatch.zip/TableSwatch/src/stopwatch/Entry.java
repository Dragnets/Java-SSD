//Entry.java
package stopwatch;

/**
 * @author Peter Rosner
 * @version 2.0 March 2013
 * Stores the basic data for a run of the stopwatch
 */
public class Entry {
    private String time;
    private String name;
    private String club;
    private String quality;
    private boolean accepted;

    /**
     * Constructor takes the basic data as parameters and populates the data members
     * @param time the time for the run
     * @param name the name of the runner
     * @param club the club of the runner
     * @param quality the quality - "Poor", "Moderate" or "Good"
     * @param accepted whether the runner has been accepted for the team
     */
    public Entry(String time, String name, String club, String quality, boolean accepted) {
        this.time = time;
        this.name = name;
        this.club = club;
        this.quality = quality;
        this.accepted = accepted;
    }
    
    /**
     * @return the time for the run as a String
     */
    public String getTime() {
        return this.time;
    }
    
    /**
     * @return the runner's name as a String
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * @return the runner's club as a String
     */
    public String getClub() {
        return this.club;
    }
    
    /**
     * @return the speed quality "Poor", "Moderate" or "Good"
     */
    public String getQuality() {
        return this.quality;
    }
    
    /**
     * @return "accepted" or "not accepted"
     */
    public String getAccepted() {
        if (accepted){
            return "accepted";
        } else {
            return "not accepted";
        }
    }
    
    /**
     * @return the concatenation of all the run data as a String
     */
    public String toString() {
        return time + " " + name + " " + club + " " + " " + quality + " " + accepted;
    }

    
}
