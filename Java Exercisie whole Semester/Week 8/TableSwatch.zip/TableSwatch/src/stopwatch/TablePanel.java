package stopwatch;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Peter Rosner Subclass of JPanel for displaying the data in table form
 * corresponding to a stopwatch run: Name, club, speed quality, and whether
 * accepted for the team
 */
public class TablePanel extends JPanel {

    //fields
    private JPanel backPanel;
    private JScrollPane tableHolder;
    private JButton backButton;
    private JTable theTable = null;
    private DefaultTableModel theTableModel = null;
    private ListSelectionModel listSelectionModel = null;
    private Vector colunmNames = null;

    /**
     * Constructor creates new DataPanel and registers inner class
     * SaveActionListener the TableSwatchController as listener for the the Save
     * button.
     *
     * @param controller the TableSwatchController instance containing this
     * inner classes
     */
    public TablePanel(TableSwatchController controller) {

        this.setLayout(new BorderLayout());
        theTable = new JTable();
        tableHolder = new JScrollPane(theTable,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        colunmNames = new Vector();
        colunmNames.add("Time");
        colunmNames.add("Name");

        colunmNames.add("Club");
        colunmNames.add("Quality");
        colunmNames.add("Accepted");

        theTableModel = new DefaultTableModel(colunmNames, 0);

        theTable.setModel(theTableModel);

        theTable.setPreferredScrollableViewportSize(new Dimension(500, 100));
        theTable.setEnabled(true);
        listSelectionModel = theTable.getSelectionModel();

        listSelectionModel.addListSelectionListener(controller.new ListListener());
        listSelectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        backButton = new JButton("Back");
        backPanel = new JPanel();
        backPanel.add(backButton);
        this.add(tableHolder, BorderLayout.CENTER);
        this.add(backPanel, BorderLayout.SOUTH);

        backButton.addActionListener(controller.new BackActionListener());


    }

    /**
     * display the records in the JTable (clearing out old display) from the
     * list obtained from the model, extracting the name, club, quality and
     * accepted/not data from each record for each row in the JTable.
     *
     * @param records the list of records obtained from the model
     */
    /*
     public void setRecords(Entry[] records) {
     Vector vectorOfVectors = new Vector();
     for (Entry element : records) {
     Vector itemParts = new Vector();
     itemParts.add(element.getTime());
     itemParts.add(element.getName());
     itemParts.add(element.getClub());
     itemParts.add(element.getQuality());
     itemParts.add(element.getAccepted());
     vectorOfVectors.add(itemParts);
     }
     theTableModel.setDataVector(vectorOfVectors, colunmNames);
     }
     */
    
    
    
    /** add the data from an Entry to the JTable 
     * @param the Entry (from the Model for the application)
     */
    public void addEntry(Entry element) {
        Vector itemParts = new Vector();
        itemParts.add(element.getTime());
        itemParts.add(element.getName());
        itemParts.add(element.getClub());
        itemParts.add(element.getQuality());
        itemParts.add(element.getAccepted());
        theTableModel.addRow(itemParts);

    }

    /**
     * Returns the data for the selected item in the JTable
     *
     * @return the data in the form of a concatenated String
     */
    public String getListSelection() {
        if (listSelectionModel.getMinSelectionIndex() == -1) {
            throw new RuntimeException("there is no selected item in getListSelection()");
        }

        Vector dataVector = theTableModel.getDataVector();
        Vector row = (Vector) dataVector.elementAt(listSelectionModel.getMinSelectionIndex());
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i
                < row.size(); i++) {
            sb.append(row.elementAt(i) + " ");
        }

        return sb.toString();
    }

    /**
     * Get the index of the item that is currently being selected
     *
     * @return the index (starting from 0)
     *
     */
    public int getListSelectionIndex() {
        return listSelectionModel.getMinSelectionIndex();
    }
}
