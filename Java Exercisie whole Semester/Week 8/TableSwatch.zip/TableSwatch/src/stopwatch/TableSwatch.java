//Stopwatch.java
package stopwatch;

/**
 * @author Peter Rosner
 * @version 2.0 January 2013
 * Contains main() method for artefact
 * Kicks off the Controller
 */
public class TableSwatch {
    
    /**
     * creates a TableSwatchController and starts it up
     */
    public static void main(String[] args) {
        //StopwatchController sc = new TableSwatchController();
        TableSwatchController sc = new TableSwatchController();
        sc.start();
    }
}
