// TableSwatchController.java
package stopwatch;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * Handles events from both the user and timer. Controller part of MVC
 * architecture, contains inner classes to handle each type of event
 *
 * @author peterrosner
 * @version 2.0 January 2013
 */
public class TableSwatchController {

    private final static int RESET = 1;
    private final static int RUNNING = 2;
    private final static int STOPPED = 3;
    private final static int LIST_DISPLAY = 4;
    private final static String ENTER_NAME =
            "Please enter a name in the name field";
    private final static String NAME_MISSING =
            "Name missing";

    //The current state
    private int theState = RESET;

    //The timer
    private Timer aTimer;
    
    //The Model - the object supplying the stopwatch time
    private ElapsedTimer elapsedTimer;

    //The View which displays the stopwatch time
    private TableSwatchView theView;
    private Logger theLogger;
    private int lastIndexSelected = -1;

    /**
     * Constructor sets up ElapsedTimer (Model) and TableSwatchView (View) and
     * gets the View to act as observer to the Model.
     */
    public TableSwatchController() {
        elapsedTimer = new ElapsedTimer();
        theView = new TableSwatchView(this);
        theView.setResetState();
        elapsedTimer.addObserver(theView);
        theLogger = new Logger();
        theLogger.addObserver(theView);
        aTimer = new Timer(50, new TimerActionListener());
    }

    /**
     * Get the view to display, the ElapsedTimer to reset (to propagate to the
     * View) and the timer to start
     */
    public void start() {
        theView.show();
        elapsedTimer.reset();
        aTimer.start();
    }

    /**
     * Listener for Start button events.
     */
    public class StartActionListener implements ActionListener {

        @Override
        /**
         * If in reset state, transition to the running state setting the
         * appropriate button sensitivities, and resetting the ElapsedTimer.
         *
         * @param event the ActionEvent from Start button triggering the
         * listener
         */
        public void actionPerformed(ActionEvent event) {
            if (theState == RESET) {
                //added 14/2/2013
                elapsedTimer.reset();
                //
                theState = RUNNING;
                theView.setRunningState();
            }
        }
    }

    /**
     * Listener for Stop button events.
     */
    public class StopActionListener implements ActionListener {

        @Override
        /**
         * If in running state, transition to the stopped state setting the
         * appropriate button sensitivities.
         *
         * @param event the ActionEvent from Stop button triggering the listener
         */
        public void actionPerformed(ActionEvent event) {
            if (theState == RUNNING) {
                theState = STOPPED;
                theView.setStoppedState();
            }
        }
    }

    /**
     * Listener for Reset button events
     */
    public class ResetActionListener implements ActionListener {

        @Override
        /**
         * If in stopped state, reset ElapsedTimer (to propagate change to View)
         * and transition to reset state setting the appropriate button
         * sensitivities.
         *
         * @param event the ActionEvent from Reset button triggering the
         * listener
         */
        public void actionPerformed(ActionEvent event) {
            if (theState == STOPPED) {
                theState = RESET;
                elapsedTimer.reset();
                theView.setResetState();
            }
        }
    }

    /**
     * Listener for Timer events
     */
    public class TimerActionListener implements ActionListener {

        @Override
        /**
         * If in running state, ask ElapsedTimer to change time (will then
         * propagate change to the View to update the display)
         *
         * @param event the ActionEvent from the Timer triggering the listener
         */
        public void actionPerformed(ActionEvent event) {
            if (theState == RUNNING) {
                elapsedTimer.changeTime();
            }
        }
    }

    /**
     * Listener for events on Save JButton
     */
    public class SaveActionListener implements ActionListener {

        @Override
        /**
         * @param event the ActionEvent from the Save button being pressed If in
         * the stopped state, Save and Reset pressed and no name entered,
         * display modal dialog box Otherwise get state of "accepted" checkbox
         * from the View and create string "accepted or not accepted", also get
         * hold of club, speed quality from View. Get hold of elapsed time from
         * the ElapsedTimer part of the Model. Put all this data in the Logger
         * (which will update the view), and then reset the time in the
         * ElapsedTimer (which will also update the view)
         */
        public void actionPerformed(ActionEvent event) {
            if (theState == STOPPED) {
                if (theView.getName().equals("")) {
                    JOptionPane.showMessageDialog(null,
                            ENTER_NAME, NAME_MISSING, JOptionPane.ERROR_MESSAGE);
                } else {
                    String acceptedString;
                    if (theView.getAccepted()) {
                        acceptedString = "accepted";
                    } else {
                        acceptedString = "not accepted";
                    }
                    theLogger.log(elapsedTimer.getTime(),
                            theView.getName(),
                            theView.getClub(),
                            theView.getSpeedQuality(),
                            theView.getAccepted());
                    elapsedTimer.reset();
                    theView.setListDisplayState();
                    theState = LIST_DISPLAY;
                }
            }
        }
    }

    /**
     * Listener for Back button pressed
     */
    public class BackActionListener implements ActionListener {

        @Override
        /**
         * @param event the ActionEvent from the Back button being pressed Go
         * back to main panel and transition to RESET
         */
        public void actionPerformed(ActionEvent event) {
            if (theState == LIST_DISPLAY) {
                theView.setResetState();
                theState = RESET;
            }
        }
    }

    /**
     * Listener for when the user selects an item in the JList
     */
    public class ListListener implements ListSelectionListener {

        @Override
        /**
         * @param le ListSelection event. Obtain whether one of multiple events,
         * and also the  event source from le For only one of the events:
         * Get the item (if any) selected by the user and print out the text and
         * position of the item.
         */
        public void valueChanged(ListSelectionEvent le) {
            if (theState == LIST_DISPLAY && !le.getValueIsAdjusting()) {
                lastIndexSelected = theView.getListSelectionIndex();
                if (lastIndexSelected != -1) {
                    String selection = theView.getListSelection();
                    System.out.println(selection + " at position " + lastIndexSelected);
                }
            }
        }
    }
}
