//TextDemo.java
/**
 * @author Peter Rosner
 * @version V0.6 November 2008
 * Used to demonstrate editing facilities of JTextComponent
 */
package textdemo;

public class TextDemo {

    public static void main(String[] args) {
        TextDemoController ctrl = new TextDemoController();
    }
}

