//TextDemoController.java
/**
 * @author Peter Rosner
 * @version V0.6 November 2008
 * Used to demonstrate editing facilities of JTextComponent
 * 
 * The translation class is dispatched ActionEvents or DocumentEvents
 * and calls the appropriate method in the presentation class to append or delete text
 * to/from the JTextArea or else to set the sensitivity of the Delete Button
 */
package textdemo;

//import java.awt.event.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

//import javax.swing.event.*;

public class TextDemoController implements ActionListener, DocumentListener {

    private TextDemoUI ui = null;
    private static int TEXT_NOT_PRESENT = 0;
    private static int TEXT_PRESENT = 1;
    private int theState = TEXT_NOT_PRESENT;

    /**
     * Constructor connects up the aggregated TextDemoUI presentation layer object
     * and provides the TextDemoController object itself as both the ActionListener and
     * the DocumentListener
     */
    public TextDemoController() {
        ui = new TextDemoUI(this, this);
    }

    /**
     * called whenever an ActionEvent is dispatched via either the Delete button or 
     * the text field using for appending text (which will result from the using
     * pressing  Enter on the keyboard.
     * @param event the ActionEvent triggering the listener
     */
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        if (command.equals("delete")) {
            ui.deleteText();
        } else if (command.equals("textField")) {
            ui.copyText();
        }
    }

    /**  
     * A method mandated by DocumentListener, called when an insertion takes place
     * in the JTextArea corresponding to the Document to which the TextDemoController 
     * is registered.
     * Will result in the Delete button  being enabled
     * @param event the DocumentEvent sent when an insertion takes place in the Document
     */
    public void insertUpdate(DocumentEvent event) {
        if (theState == TEXT_NOT_PRESENT) {
            ui.setEnableDelete();
            theState = TEXT_PRESENT;
        }
    }

    /**  
     * A method mandated by DocumentListener, called when a text attributes change takes 
     * place in the JTextArea corresponding to the Document to which the TextDemoController 
     * is registered.
     * In our case we are not interested in these,
     * so the method is empty
     * @param event the DocumentEvent sent when a change takes place in the Document
     */
    public void changedUpdate(DocumentEvent event) {
    }

    /**  
     * A method mandated by DocumentListener, called when a deletion takes place
     * in the JTextArea corresponding to the Document to which the TextDemoController 
     * is registered.
     * will cause the Delete button to be enabled or disabled
     * @param event the DocumentEvent sent when a deletion takes place in the Document
     */
    public void removeUpdate(DocumentEvent event) {
        if (!ui.textPresent()) {
            ui.setDisableDelete();
            theState = TEXT_NOT_PRESENT;
        }
    }
}
