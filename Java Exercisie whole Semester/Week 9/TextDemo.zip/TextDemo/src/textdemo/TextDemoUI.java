//TextDemoUI.java
/**
 * @author Peter Rosner
 * @version V0.6 November 2008
 * Used to demonstrate editing facilities of JTextComponent
 * 
 * A TextArea is constructed and its Document model is extracted
 * The DocumentListener that is supplied is registered with the model.
 * A JTextField is also constructed and the supplied ActionListener registers with it
 * such that when Enter is pressed the text is appended to the end of the JTextArea.
 * The Delete button is disabled if there is nothing in the text area. 
 * Otherwise the Delete button deletes the text in the Document, causing
 * the text display in the text area to be deleted as a consequence.
 */

package textdemo;

//import java.awt.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

public class TextDemoUI extends JPanel {
   
  
  private JTextArea lotsOfWords = null;
  private JTextField appendField = null;
  private JLabel appendLabel = null;
  private JButton deleteButton = null;  
  private Document doc = null; //Document Model of lotsOfWords JTextArea
  
  JPanel topPanel = null;
  JPanel textPanel = null;
  Box appendPanel = null;
  
  JPanel buttonPanel = null;
  
  private JFrame frame = null;
  
  /**
   Initializes resources and components
   */
  
  
  public TextDemoUI(DocumentListener sendDocumentEventsHere, 
          ActionListener sendActionEventsHere) {
    
    this.setResources();
    
    frame = new JFrame("Text Demo");
    
    topPanel = new JPanel();
    
    topPanel.setLayout(new BorderLayout());
    
    
    textPanel = new JPanel();
    textPanel.setLayout(new BorderLayout());
    
    appendLabel = new JLabel("Append:");
    
    appendField = new JTextField(15);
    appendField.setActionCommand("textField");
    appendField.addActionListener(sendActionEventsHere);
    
    lotsOfWords = new JTextArea(6,20);
    lotsOfWords.setLineWrap(true);
    
    
    lotsOfWords.setBorder(new TitledBorder(LineBorder.createBlackLineBorder(),
                                     "Lots of words"));
    
    doc = lotsOfWords.getDocument(); //gets Document model
    doc.addDocumentListener(sendDocumentEventsHere);
    
    appendPanel = Box.createHorizontalBox();
    appendPanel.add(appendLabel);
    appendPanel.add(Box.createRigidArea(new Dimension(10,0)));
    appendPanel.add(appendField);
    appendPanel.add(Box.createRigidArea(new Dimension(40,0)));
    appendPanel.setBorder(BorderFactory.createEmptyBorder(20, 3
            , 10, 0));
   
    
    textPanel.add(lotsOfWords,BorderLayout.CENTER);
    textPanel.add(appendPanel,BorderLayout.NORTH);
    
    
    buttonPanel = new JPanel();
    deleteButton = new JButton("Delete");
    deleteButton.addActionListener(sendActionEventsHere);
    deleteButton.setActionCommand("delete");
    deleteButton.setEnabled(false);
    buttonPanel.add(deleteButton);
    
    topPanel.add(textPanel,BorderLayout.CENTER);
    topPanel.add(buttonPanel,BorderLayout.SOUTH);
    
    frame.add(topPanel);
    frame.pack();
    setResources();
    frame.setVisible(true);
    
  } // End constructor
  

  /**
   * Tests if the text area has any text inside it
   * by testing to see if the length of the associated Document is 0
   * @return true if the text area has text, otherwise false
   */
  public boolean textPresent() {
      return doc.getLength() != 0;
  }
  
  /**
   * Enable deleting
   */
  public void setEnableDelete(){
      deleteButton.setEnabled(true);
  }
  
  /**
   * disable deleting
   */
  public void setDisableDelete() {
      deleteButton.setEnabled(false);
  }
  
  /**
   * Deletes the contents of the Document for lotsOfWords JTextArea
   */
  public void deleteText() {
      try {
        doc.remove(0,doc.getLength());
      } catch (BadLocationException e) {
        throw new RuntimeException("Delete failed");
      }
  }
  
  
  /**
   * Copies text across from appendField to lotsOfWords JTextArea and 
   * then clears appendField
   */
  public void copyText() {
      lotsOfWords.insert(appendField.getText(),doc.getLength());
      appendField.setText(""); 
  }
 
  /**
   sets the resources to determine the look of the components
   */
  private void setResources() { 
    
    ColorUIResource defaultBackground = new 
      ColorUIResource( Color.white);
    ColorUIResource defaultForeground = new 
      ColorUIResource( Color.black);
    ColorUIResource disabledColor = new 
      ColorUIResource( Color.lightGray);
    
    FontUIResource  smallFont = new FontUIResource( 
                                                   new Font( "Dialog", Font.BOLD, 12));
    FontUIResource  bigFont   = new FontUIResource( 
                                                   new Font( "Dialog", Font.BOLD, 18));
    
    
    UIManager.put( "Button.background",  
                  defaultBackground);
    UIManager.put( "Button.foreground",  
                  defaultForeground);
    UIManager.put( "Button.disabledText",  
                  disabledColor);
    UIManager.put( "Button.font", smallFont);
    
    
    UIManager.put( "Panel.background",  
                  defaultBackground);
    UIManager.put( "Panel.foreground",  
                  defaultForeground);
  } // End setResources. 
  
  
} // End of TextDemo
